# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
import torch

from detectron2.layers import ShapeSpec

from .meta_arch import (
    META_ARCH_REGISTRY,
    ConPropNetProposalNetwork,
    build_model,
)

from .proposal_generator import (
    PROPOSAL_GENERATOR_REGISTRY,
    ConPropNetRPN,
    build_proposal_generator,
    RPN_HEAD_REGISTRY,
    build_rpn_head,
)

from .config import add_conpropnet_config
from .argparser import argument_parser

_EXCLUDE = {"torch", "ShapeSpec"}
__all__ = [k for k in globals().keys() if k not in _EXCLUDE and not k.startswith("_")]

########
##  From meta_arch.
########
from .build import META_ARCH_REGISTRY, build_model  # isort:skip

# import all the meta_arch, so they will be registered
from .rcnn import ConPropNetProposalNetwork


########
##  From proposal_generator.
########
from .build import PROPOSAL_GENERATOR_REGISTRY, build_proposal_generator
from .rpn import RPN_HEAD_REGISTRY, build_rpn_head

from .rpn import ConPropNetRPN
